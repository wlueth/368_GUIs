package CyberPet;

@SuppressWarnings("serial")
public class NoPetException extends Exception {
	public NoPetException(String message){
		super(message);
	}
}
