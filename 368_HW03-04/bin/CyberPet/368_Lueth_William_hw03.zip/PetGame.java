package CyberPet;

public class PetGame {

	public static void main(String[] args){
		// TODO: Main Method
	}
}
