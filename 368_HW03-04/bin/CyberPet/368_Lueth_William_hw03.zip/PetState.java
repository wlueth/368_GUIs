package CyberPet;

public enum PetState {
	SLEEPING,
	THINKING,
	PLAYING,
	EATING,
	MOVING,
	RELAXING,
	DEAD;
}
