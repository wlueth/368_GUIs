package CyberPet;

public class HealthStatus{
	//Instance Variables
	private int hunger, tiredness, loneliness, energy, overallScore;
	private healthLevel health;
	
	private final int MIN = 0;
	private final int MAX = 10;

	public enum healthLevel{
		Unhealthy,
		Healthy,
		Superstar;
	}
	
	public HealthStatus(int inHunger, int inTiredness, int inLoneliness, int inEnergy){
		this.hunger = inHunger;
		this.tiredness = inTiredness;
		this.loneliness = inLoneliness;
		this.energy = inEnergy;
	}
	
	public void setHealth(int inHunger, int inTiredness, int inLoneliness, int inEnergy){
		calcScore();
		
		if(overallScore < 12){
			this.health = healthLevel.Unhealthy;
		}
		else if(overallScore < 25){
			this.health = healthLevel.Healthy;
		}
		else{
			this.health = healthLevel.Superstar;
		}
	}
	
	private int calcScore(){
		calcHelp();
		overallScore = hunger + tiredness + loneliness + energy;
		return overallScore;
	}
	
	private void calcHelp(){
		while(MIN > hunger)
			this.hunger += 10;
		while(MAX < hunger)
			this.hunger -= 10;
		while(MIN > tiredness)
			this.tiredness += 10;
		while(MAX < tiredness)
			this.tiredness -= 10;
		while(MIN > loneliness)
			this.loneliness += 10;
		while(MAX < loneliness)
			this.loneliness -= 10;
		while(MIN > energy)
			this.energy += 10;
		while(MAX < energy)
			this.energy -= 10;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return health.name();
	}
	
}